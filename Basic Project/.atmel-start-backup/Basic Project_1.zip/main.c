#include <atmel_start.h>

#define PORTA PORT->Group[0]

int main(void)
{
	/* Initializes MCU, drivers and middleware */
	atmel_start_init();

	// Setup a pin for control
	// Setup PA15
	PORTA.DIR.reg		 |= 1 << 15;
	// Setup PA22 as input, pull down, EXTINT[6]
	PORTA.DIR.reg		 &= ~(1 << 22);
	PORTA.OUT.reg		 &= ~(1 << 22);
	PORTA.PINCFG[22].reg |= 1 << 1 | 1 << 2 | 1 << 0;

	// Setup Interrupt for Pin PA22
	REG_GCLK_CLKCTRL = GCLK_CLKCTRL_ID_EIC | GCLK_CLKCTRL_GEN_GCLK0 | GCLK_CLKCTRL_CLKEN;
	REG_PM_APBAMASK |= PM_APBAMASK_EIC;
	EIC->INTENSET.reg	= EIC_INTENSET_EXTINT6;
	EIC->CONFIG[0].reg 	|= EIC_CONFIG_FILTEN6 | EIC_CONFIG_SENSE6_HIGH;
	EIC->CTRL.reg		|= EIC_CTRL_ENABLE; // Enable

	NVIC_EnableIRQ(EIC_IRQn);
	NVIC_SetPriority(EIC_IRQn, 3);
	
	// Setup USART 
	// Pins
	PORTA.DIR.reg	|= 1 << 10; // Output Pin
	PORTA.OUTSET.reg = 1 << 10; // Set Pin A10 Out High
	PORTA.PINCFG[10].reg |= 1 << 0; // Enable PINMUX for pin A10

	PORTA.DIR.reg	&= ~(1 << 11); // Input Pin
	PORTA.PINCFC[11].reg |= 1 << 0 | 1 << 1; // Enable PINMUX and input for Pin A11

	PORTA.PMUX[6]	= (uint8_t)0x33; // Set odd and even to pin function D 

	// SERCOM
	GCLK->CLKCTRL.reg = (GCLK_CLKCTRL_ID_SERCOM2_CORE | GCLK_CLKCTRL_GEN_GCLK0 | GCLK_CLKCTRL_CLKEN);
	
	uint16_t bValue;
	bValue = calcul

	// Set Onboard LED to off as default
	PORTA.OUT.reg &= ~(1 << 17);
	/* Replace with your application code */
	while (1) {
		PORTA.OUT.reg |= 1 << 15;
		delay_ms(100);
		PORTA.OUT.reg &= ~(1 << 15);
		delay_ms(100);
	}
}

void EIC_Handler()
{
	if (EIC->INTFLAG.reg & 1 << 6)
	{
		PORTA.OUT.reg |= 1 << 17;
		delay_ms(500);
		PORTA.OUT.reg &= ~(1 << 17);

		EIC->INTFLAG.reg |= 1 << 6;
	}
}
